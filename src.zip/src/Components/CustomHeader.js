import React from 'react';
import {View, Text, Image} from 'react-native';

const CustomHeader = ({name, profilePictureUri}) => {
  return (
    <View style={{flexDirection: 'row', alignItems: 'center'}}>
      <Image
        source={{uri: profilePictureUri}}
        style={{width: 40, height: 40, borderRadius: 20, marginRight: 10}}
      />
      <Text>{name}</Text>
    </View>
  );
};

export default CustomHeader;
