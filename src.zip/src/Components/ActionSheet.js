import ActionSheet from 'react-native-actions-sheet';

export default function App() {
  const actionSheetRef = useRef < ActionSheetRef > null;

  return (
    <ActionSheet ref={actionSheetRef}>
      <Text>Hi, I am here.</Text>
    </ActionSheet>
  );
}
