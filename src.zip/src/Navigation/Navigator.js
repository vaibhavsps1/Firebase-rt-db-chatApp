import React, {useEffect, useState} from 'react';
import Login from '../Screen/Before_Login/Login';
// import Register from '../Screen/Before_Login/Register';
// import Chat from '../Screen/After_Login/Chat';

import {NavigationContainer, useNavigation} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import auth from '@react-native-firebase/auth';
import Chat from '../Screen/After_Login/Chat';
import Dashboard from '../Screen/After_Login/Dashboard';
import Register from '../Screen/Before_Login/Register';
import {createDrawerNavigator} from '@react-navigation/drawer';
import CustomDrawer from '../Components/CustomDrawer';

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

export const MyDrawer = () => {
  return (
    <Drawer.Navigator
      drawerContent={props => <CustomDrawer {...props} />}
      screenOptions={{
        headerShown: false,
        drawerActiveBackgroundColor: '#F4F4F6',
        drawerActiveTintColor: 'black',
        drawerStyle: {
          width: '100%',
        },
        drawerLabelStyle: {
          fontWeight: 'bold',
        },
      }}>
      <Drawer.Screen
        name="home"
        options={{headerShown: false}}
        component={Dashboard}
      />
    </Drawer.Navigator>
  );
};

//start from here
const Navigation = () => {
  // const navigation = useNavigation();
  const [state, setstate] = useState({loading: true, currentUser: null});

  useEffect(() => {
    auth().onAuthStateChanged(user => {
      if (user) {
        var uid = user.uid;
        console.log('uid onAuthStateChanged', uid);
        setstate(prev => ({...prev, currentUser: uid, loading: false}));
        // getToken();
      } else {
        //console.log('user is signout')
        setstate(prev => ({...prev, currentUser: null, loading: false}));
      }
    });

    // getRequest(); // permissions

    // when you app will be in the foreground
    // const unsubscribe = messaging().onMessage(async remoteMessage => {
    //   Alert.alert('A new FCM message arrived!', JSON.stringify(remoteMessage));
    //   // if(remoteMessage.data.url === 'google'){
    //   //
    //   // }
    // });

    // messaging().setBackgroundMessageHandler(async remoteMessage => {
    //console.log('Message handled in the background!', remoteMessage);
    // });
  }, []);

  // const getRequest = async () => {
  //   const authStatus = await messaging().requestPsermission();
  //   const enabled =
  //     authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
  //     authStatus === messaging.AuthorizationStatus.PROVISIONAL;
  //   if (enabled) {
  //     //console.log('Authorization status:', authStatus);
  //     getToken();
  //   }
  // };

  // const getToken = () => {
  //   messaging()
  //     .getToken()
  //     .then(token => {
  //       console.log('token for notifications', token);
  //       if (auth().currentUser !== null) {
  //         //   firestore()
  //         //     .collection('users')
  //         //     .doc(auth().currentUser.uid)
  //         //     .update({token: token});

  //         database()
  //           .ref(`/users/${auth().currentUser.uid}`)
  //           .update({token})
  //           .then(() => {
  //             console.log('token is saved');
  //           });
  //       }
  //     })
  //     .catch(error => {
  //       console.log('erro to get a token', error);
  //     });
  //   //taxi > employees, drivers , customers // all
  //   // messaging()
  //   //   .subscribeToTopic('customers')
  //   //   .then(() => {
  //   //     //console.log('subscribeed to topic customers')
  //   //   });
  // };

  const loginPage = () => {
    const currentUser = auth().currentUser;
    console.log(currentUser, 'this is current user');
    //console.log('currentUser on router page',currentUser)
    setstate(prev => ({...prev, currentUser, loading: false}));
  };

  return (
    <NavigationContainer>
      <Stack.Navigator>
        {state.currentUser === null ? (
          <>
            <Stack.Screen name="login" component={Login} />
            <Stack.Screen name="register" component={Register} />
          </>
        ) : (
          <>
            <Stack.Screen
              name="home"
              options={{headerShown: false}}
              component={Dashboard}
            />
            <Stack.Screen
              name="chat"
              options={{headerShown: true}}
              component={Chat}
            />
            <Stack.Screen
              name="MyDrawer"
              options={{headerShown: true}}
              component={MyDrawer}
            />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default Navigation;
