import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Image,
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import auth from '@react-native-firebase/auth';
import _ from 'lodash';

import database from '@react-native-firebase/database';
import {useNavigation} from '@react-navigation/native';

const Dashboard = () => {
  const navigation = useNavigation();
  const [usersList, set_usersList] = useState([]);
  useEffect(() => {
    var user = auth().currentUser;

    database()    
      .ref('/users')
      .once('value')
      .then(snapshot => {
        var dataArray = [];
        let data = snapshot.val();
        _.map(data, (each, index) => {
          // to hide the self chat
          if (index !== user.uid) {
            dataArray.push({id: index, ...each});
          }
        });
        set_usersList(dataArray);
      })
      .catch(ER => {
        console.log('er', ER);
      });
  }, []);

  const renderItem = ({item}) => {
    return (
      <TouchableOpacity
        onPress={() => navigation.navigate('chat', {chatUser: item})}
        style={{
          flexDirection: 'row',
          borderBottomWidth: 0.5,
          borderWidth: 1,
          width: '95%',
          height: 80,
          margin: 10,
          borderRadius: 10,
          overflow: 'hidden',
          alignItems: 'center',
          backgroundColor: 'white',
        }}>
        <Image
          style={{height: 80, width: 120}}
          source={{
            uri: 'https://img.freepik.com/premium-vector/man-avatar-profile-picture-vector-illustration_268834-538.jpg',
          }}
          resizeMode="contain"
        />
        <Text style={{paddingLeft: 20, color: 'black'}}>{item.name}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <>
      <View
        style={{
          paddingLeft: 20,
          maxHeight: 50,
          alignItems: 'flex-end',
          justifyContent: 'space-between',
          backgroundColor: '#fafafa',
          flexDirection: 'row',
        }}>
        <TouchableOpacity
          style={{marginTop: 20, width: 40, height: 40}}
          onPress={() => navigation.openDrawer()}>
          <AntDesign name={'menufold'} size={20} color={'tomato'} />
        </TouchableOpacity>
        <TouchableOpacity
          style={{marginTop: 20, width: 40, height: 40}}
          onPress={() => auth().signOut()}>
          <AntDesign name={'logout'} size={20} color={'tomato'} />
        </TouchableOpacity>
      </View>
      <FlatList
        data={usersList}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        style={{backfaceVisibility: 'hidden', lineHeight: 84}}
      />
    </>
  );
};
export default Dashboard;
