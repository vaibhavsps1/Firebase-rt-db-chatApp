import React, {useEffect, useState, useRef} from 'react';
import {
  Text,
  TouchableOpacity,
  TextInput,
  View,
  FlatList,
  Dimensions,
  ImageBackground,
  Image,
} from 'react-native';
import database from '@react-native-firebase/database';
import auth, {firebase} from '@react-native-firebase/auth';
import storage from '@react-native-firebase/storage';
import Feather from 'react-native-vector-icons/Feather';
import _ from 'lodash';
import Moment from 'moment';
import moment from 'moment';
import CustomHeader from '../../Components/CustomHeader';
import ImageOptionsModal from '../../Components/ImageOptionsModal';
const {width} = Dimensions.get('window');

const Chat = ({navigation, route}) => {
  const chatUser = route.params.chatUser;
  const [chatmsg, set_chatmsg] = useState('');
  const [currentuser, set_currentuser] = useState({uid: 1});
  const [chatlist, set_chatlist] = useState([]);

  const [visible, setVisible] = useState(false);
  const [img, setImg] = useState(null);
  const [fileType, setFileType] = useState('text');
  const [url, setUrl] = useState(null);

  const flatlistref = useRef(null);

  useEffect(() => {
    if (currentuser !== null) {
      database()
        .ref(`users/${currentuser.uid}/chat/${chatUser.id}`)
        .on('value', snapshot => {
          var dataArray = [];
          var pendingtoReadStatus = [];
          let data = snapshot.val();
          _.map(data, (each, index) => {
            dataArray.push({id: String(`s_${index}`), ...each});
            if (
              each.receiver_id === currentuser.uid &&
              each.receiver_read === false
            ) {
              pendingtoReadStatus[index];
            }
          });
          dataArray = _.orderBy(dataArray, ['timecreated'], ['asc']);
          setTimeout(() => {
            set_chatlist([...dataArray]);
          }, 200);
        });
    }
  }, [currentuser]);

  useEffect(() => {
    const currentUser = auth().currentUser;
    set_currentuser(currentUser);
    navigation.setOptions({
      headerTitle: () => (
        <CustomHeader name={chatUser.name} profilePictureUri={chatUser.image} />
      ),
    });
  }, []);

  const renderItem = ({item}) => {
    console.log(item, 'thisi s item');
    return (
      <View
        style={{
          marginVertical: 10,
          alignItems:
            item.sender_id === currentuser.uid ? 'flex-end' : 'flex-start',
        }}>
        <View
          style={{
            borderRadius: 16,
            borderTopEndRadius: item.sender_id === currentuser.uid ? 0 : 16,
            borderTopStartRadius: item.sender_id === currentuser.uid ? 16 : 0,
            backgroundColor:
              item.sender_id === currentuser.uid ? '#205042' : 'grey',
            paddingVertical: 5,
            paddingHorizontal: 15,
            justifyContent: 'center',
            width: width * 0.7,
          }}>
          {item?.fileType === 'image' ? (
            <Image
              source={{
                uri: true
                  ? String(item?.image_url)
                  : 'file:///storage/emulated/0/Android/data/com.customchatpoc/files/Pictures/ad1a1dd4-acc5-4195-939b-30c3e396f536.jpg',
              }}
              style={{height: 100, width: 100}}
            />
          ) : (
            <Text
              style={{
                color: 'white',
                fontSize: 11,
                lineHeight: 15,
                paddingVertical: 8,
              }}>
              {item.content}
            </Text>
          )}
          <Text
            style={{
              fontSize: 9,
              textAlign: 'right',
              paddingTop: 5,
              paddingRight: 4,
            }}>
            {moment(item.timecreated).format('HH:mm:ss')}
          </Text>
        </View>
      </View>
    );
  };

  const onImageReceived = async data => {
    let allImageArr = [];
    for (let i = 0; i < data.length; i++) {
      const imageUri =
        Platform.OS === 'ios'
          ? data[i].path.replace('file://', '')
          : data[i].path;
      let imageName = data[i].path?.split('/')?.pop();

      const imageObj = {
        path: imageUri,
        imageName,
        size: data[i].size,
        type: data[i].mime,
      };
      const imageArr = [imageObj];
      allImageArr.push(...imageArr);
    }
    setImg(allImageArr[0].path);
    setFileType('image');
    const uniqueName = Date.now();
    await storage()
      .ref(uniqueName + '.jpeg')
      .putFile(allImageArr[0].path);
    const url = await storage()
      .ref(uniqueName + '.jpeg')
      .getDownloadURL();
    setUrl(url);
    var t = Moment(new Date()).valueOf();
  };

  const submitForm = async () => {
    // const database = getDatabase();
    // const messageRef = push(ref(database, 'chat-messages'));
    try {
      // Generate a unique ID for the message
      const messageId = database().ref().push().key;
      // // Current timestamp
      const timestamp = Moment(new Date()).valueOf();

      // // Upload the image if an image file is selected
      // let imageUrl = '';
      // if (img) {
      //   const imageRef = storage().ref(`chatImages/${messageId}`);
      //   await imageRef.put(img);
      //   imageUrl = await imageRef.getDownloadURL();
      //   console.log('i ama here --->>>', imageUrl);
      // }

      // Create the message object
      const msgContent = {
        content: chatmsg,
        image_url: url, // Add the image URL to the message
        fileType,
        sender_id: currentuser.uid,
        receiver_id: chatUser.id,
        timecreated: timestamp,
        timecreatedHuman: Moment().format('DD-MM-YYYY HH:mm:ss a'),
        status: true,
        sender_read: true,
        receiver_read: false,
      };
      console.log('this is msg', msgContent);
      // Update the messages in both users' chat nodes
      database()
        .ref(`users/${currentuser.uid}/chat/${chatUser.id}/${messageId}`)
        .update(msgContent);
      database()
        .ref(`users/${chatUser.id}/chat/${currentuser.uid}/${messageId}`)
        .update(msgContent);

      // Clear the chat message input
      set_chatmsg('');
      // Clear the selected image (if any)
      setImg(null);
      setFileType('text');
    } catch (error) {
      // Handle error
      console.error('Error sending message:', error);
    }
  };

  return (
    <ImageBackground
      source={{
        uri: 'https://i.pinimg.com/736x/8c/98/99/8c98994518b575bfd8c949e91d20548b.jpg',
      }}
      style={{flex: 1}}
      resizeMode="cover">
      <View style={{flex: 1}}>
        <View style={{paddingHorizontal: 6, marginBottom: 65}}>
          <FlatList
            data={chatlist}
            renderItem={renderItem}
            keyExtractor={item => item.id}
            ListEmptyComponent={
              <View style={{alignItems: 'center'}}>
                <Text style={{color: 'grey', fontSize: 10}}>no message</Text>
              </View>
            }
            contentContainerStyle={{
              paddingBottom: 1,
              paddingHorizontal: 10,
            }}
            ref={flatlistref}
            onContentSizeChange={() =>
              flatlistref.current.scrollToEnd({animated: true})
            }
          />
          <ImageOptionsModal
            visibility={visible}
            setVisibility={setVisible}
            onImageCaptured={onImageReceived}
            onImageSelected={onImageReceived}
          />
        </View>
        {/* msg sending component */}
        <View
          style={{
            flexDirection: 'row',
            position: 'absolute',
            width,
            height: 70,
            bottom: 0,
            right: 0,
            alignItems: 'center',
            elevation: 2,
            backgroundColor: '#a8e4d2',
          }}>
          <TouchableOpacity
            style={{flex: 1, paddingLeft: 15}}
            onPress={() => {
              // open action sheet
              setVisible(true);
            }}>
            <Feather name={'plus-circle'} size={30} color={'black'} />
          </TouchableOpacity>
          <View style={{flex: 4}}>
            {fileType === 'image' ? (
              <View
                style={{
                  paddingHorizontal: 10,
                  paddingVertical: 4,
                  width: width * 0.6,
                  backgroundColor: 'white',
                  borderColor: '#73d3b7',
                  borderRadius: 18,
                  overflow: 'hidden',
                }}>
                <View>
                  <Image source={{uri: img}} style={{width: 50, height: 50}} />
                  <TouchableOpacity
                    onPress={() => {
                      setImg(null);
                      setFileType('text');
                    }}
                    style={{
                      backgroundColor: 'black',
                      position: 'absolute',
                      left: 45,
                      top: -4,
                      borderRadius: 14,
                    }}>
                    <Feather name={'x'} size={12} color={'white'} />
                  </TouchableOpacity>
                </View>
              </View>
            ) : (
              <TextInput
                value={chatmsg}
                onChangeText={set_chatmsg}
                maxLength={200}
                multiline
                numberOfLines={2}
                style={{
                  color: 'black',
                  height: 50,
                  paddingHorizontal: 8,
                  paddingVertical: 2,
                  width: width * 0.6,
                  backgroundColor: 'white',
                  borderColor: '#73d3b7',
                  borderRadius: 18,
                }}
              />
            )}
          </View>
          <View style={{flex: 1}}>
            <TouchableOpacity
              style={{
                width: 52,
                height: 52,
                borderRadius: 26,
                backgroundColor: '#307863',
                justifyContent: 'center',
                alignItems: 'center',
              }}
              disabled={String(chatmsg).length < 1 && !url}
              onPress={() => {
                submitForm();
              }}>
              <Feather name={'send'} size={22} color={'black'} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ImageBackground>
  );
};

export default Chat;
