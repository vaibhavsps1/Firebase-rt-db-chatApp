import {View, Text, TextInput, Button, TouchableOpacity} from 'react-native';
import React, {useState, useEffect} from 'react';
import database from '@react-native-firebase/database';
import auth from '@react-native-firebase/auth';
import Feather from 'react-native-vector-icons/Feather';
import toast from 'react-native-simple-toast';
import ImageOptionsModal from '../../Components/ImageOptionsModal';

const Register = ({navigation, route}) => {
  const [state, setState] = useState({
    fullName: '',
    email: '',
    password: '123456789',
    passwordHidden: false,
    loader: false,
    emailTestFail: null,
    passwordTestFail: null,
    uri: 'https://img.freepik.com/premium-vector/man-avatar-profile-picture-vector-illustration_268834-538.jpg',
  });
  const [visible, setVisible] = useState(false);
  const [setUrl] = useState(false);

  const onChangeName = text => {
    setState(prev => ({...prev, fullName: text}));
  };
  const onChangeEmail = text => {
    setState(prev => ({...prev, email: text}));
  };
  const onChangePassword = text => {
    setState(prev => ({...prev, password: text}));
  };
  // const validEmail = () => {
  //   console.log(
  //     'this line will trigger when we move from email to password field',
  //   );
  //   const pattern =
  //     /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
  //   console.log(pattern.test(state.email));
  //   setState(prev => ({...prev, emailTestFail: !pattern.test(state.email)}));
  // };

  // const validPassword = () => {
  //   console.log('state.password value is', state.password);
  //   var pass = String(state.password).trim();
  //   console.log('pass', pass, pass.length, !pass.length > 6);
  //   setState(prev => ({...prev, passwordTestFail: !(pass.length > 6)}));
  // };

  // useEffect(() => {
  //   auth()
  //     .createUserWithEmailAndPassword(state.email, '12345678')
  //     .then(userCredential => {
  //       database().ref(`users/${userCredential.user.id}`).update({
  //         name: state.fullName,
  //         email: state.email,
  //       });
  //       toast.show('you are successfully registered');
  //       auth().signInWithEmailAndPassword(email, password);
  //       // console.log('userCred', userCredential);
  //       // // SignIn
  //       // var user = userCredential.user;
  //     })
  //     .catch(err => {
  //       console.log('error to login', err);
  //       toast.show('error to login');
  //     });
  // }, []);

  const onImageReceived = async data => {
    let allImageArr = [];
    for (let i = 0; i < data.length; i++) {
      const imageUri =
        Platform.OS === 'ios'
          ? data[i].path.replace('file://', '')
          : data[i].path;
      let imageName = data[i].path?.split('/')?.pop();

      const imageObj = {
        path: imageUri,
        imageName,
        size: data[i].size,
        type: data[i].mime,
      };
      const imageArr = [imageObj];
      allImageArr.push(...imageArr);
    }
    setImg(allImageArr[0].path);
    const uniqueName = Date.now();
    await storage()
      .ref(uniqueName + '.jpeg')
      .putFile(allImageArr[0].path);
    const url = await storage()
      .ref(uniqueName + '.jpeg')
      .getDownloadURL();
    setUrl(url);
    var t = Moment(new Date()).valueOf();
  };

  const submitForm = () => {
    const fullName = String(state.fullName).trim().toLowerCase();
    const fullname_test = fullName.length > 2;
    if (!fullname_test) {
      setState(prev => ({...prev, fullNameTestFail: true}));
      return;
    } else {
      setState(prev => ({...prev, fullNameTestFail: false}));
    }

    // email validation starts here //
    const email = String(state.email).trim().toLowerCase();
    const pattern =
      /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    var email_test = pattern.test(email); // true , false
    if (email_test === false) {
      setState(prev => ({...prev, emailTestFail: true}));
      return;
    }
    if (email_test) {
      setState(prev => ({...prev, emailTestFail: false}));
    }
    // email validation ends here //

    // password validation starts here //
    const password = String(state.password).trim();
    if (password.length >= 6) {
      setState(prev => ({...prev, passwordTestFail: false}));
    } else {
      setState(prev => ({...prev, passwordTestFail: true}));
      return;
    }

    //toast.show('everything is good so far')

    auth()
      .createUserWithEmailAndPassword(email, '123456789')
      .then(userCredential => {
        database()
          .ref(`users/${userCredential.user.uid}`)
          .update({name: state.fullName, email: state.email, image: state.uri});
        toast.show('you are registered successfully');
        auth().signInWithEmailAndPassword(email, password);
      })
      .catch(err => {
        console.log('error to login', err);
        toast.show('error to login');
      });
  };

  return (
    <View style={{flex: 1, backgroundColor: 'white'}}>
      <View style={{paddingHorizontal: 16, paddingTop: 40}}>
        <TextInput
          style={{
            color: 'grey',
            paddingVertical: 12,
            paddingHorizontal: 16,
            borderColor: '#d8d8e1',
            borderWidth: 1,
            borderRadius: 16,
          }}
          onChangeText={text => onChangeName(text)}
          value={state.fullname}
          placeholder={'Type your name here'}
          placeholderTextColor="grey"
        />
        {state.fullnameTestFail === true && (
          <Text style={{color: 'red', fontSize: 10, paddingLeft: 20}}>
            invalid name . min 3 characters required
          </Text>
        )}
        <TextInput
          style={{
            color: 'grey',
            paddingVertical: 12,
            paddingHorizontal: 16,
            borderColor: '#d8d8e1',
            borderWidth: 1,
            borderRadius: 16,
            marginTop: 20,
          }}
          onChangeText={text => onChangeEmail(text)}
          value={state.email}
          placeholder={'Type your email here'}
          placeholderTextColor={'grey'}
        />
        {state.emailTestFail === true && (
          <Text style={{color: 'red', fontSize: 10, paddingLeft: 20}}>
            invalid email
          </Text>
        )}

        {/*state.emailTestFail === false && (
                        <Text style={{ color: 'green', fontSize: 10, paddingLeft: 20 }}>valid email</Text>
                      )*/}

        <View
          style={{
            flexDirection: 'row',
            marginTop: 20,
            alignItems: 'center',
            borderColor: '#d8d8e1',
            borderWidth: 1,
            borderRadius: 16,
          }}>
          <View style={{flex: 9}}>
            <TextInput
              style={{
                color: 'grey',
                paddingVertical: 12,
                paddingHorizontal: 16,
              }}
              onChangeText={text => onChangePassword(text)}
              value={state.password}
              secureTextEntry={state.passwordHidden}
              placeholder={'Type your password here'}
              placeholderTextColor={'grey'}
            />
          </View>

          <TouchableOpacity
            onPress={() =>
              setState(prev => ({
                ...prev,
                passwordHidden: !state.passwordHidden,
              }))
            }
            style={{flex: 1}}>
            <Feather
              name={state.passwordHidden ? 'eye' : 'eye-off'}
              size={13}
              color={'black'}
            />
          </TouchableOpacity>
        </View>

        {state.passwordTestFail === true && (
          <Text style={{color: 'red', fontSize: 10, paddingLeft: 20}}>
            invalid password
          </Text>
        )}

        {/*state.passwordTestFail === false && (
                        <Text style={{ color: 'green', fontSize: 10, paddingLeft: 20 }}>valid password</Text>
                      )*/}

        <TouchableOpacity
          onPress={() => submitForm()}
          style={{
            marginTop: 20,
            height: 56,
            borderRadius: 16,
            padding: 8,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{fontSize: 18, lineHeight: 20}}>
            Select Profile Image
          </Text>
        </TouchableOpacity>
        <ImageOptionsModal
          visibility={visible}
          setVisibility={setVisible}
          onImageCaptured={onImageReceived}
          onImageSelected={onImageReceived}
        />
        <TouchableOpacity
          onPress={() => submitForm()}
          style={{
            marginTop: 20,
            height: 56,
            backgroundColor: '#333333',
            borderRadius: 16,
            padding: 8,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{fontSize: 18, lineHeight: 20, color: '#FCFCFC'}}>
            Register
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Register;
