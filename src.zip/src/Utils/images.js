export const camera = require("../Assets/icons/camera.png");
export const gallery = require("../Assets/icons/gallery.png");